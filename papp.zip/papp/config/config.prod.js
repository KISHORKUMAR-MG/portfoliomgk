window.config = {
    name: "#{USER_NAME}#",
    title: "#{USER_TITLE}#",
    bio: "#{USER_BIO}#",
    location: "#{USER_LOCATION}#",
    email: "#{USER_EMAIL}#",
    image: "#{USER_IMAGE}#"
  };
